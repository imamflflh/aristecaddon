import {ScreenDisplay} from "./../../libs/ui-from-dialogue/classes.js";
import {DEBUG_STICK_ENTITY_SCREEN_EVENT} from "./entities/debug_stick_entity.js";
/*import {EQUIPMENT_EDITOR_SCREEN_EVENT} from "./entities/equipment_editor.js";*/
export const MOB_BATTLES_SCREENS = new ScreenDisplay();

MOB_BATTLES_SCREENS.register(DEBUG_STICK_ENTITY_SCREEN_EVENT);
/*MOB_BATTLES_SCREENS.register(EQUIPMENT_EDITOR_SCREEN_EVENT);*/