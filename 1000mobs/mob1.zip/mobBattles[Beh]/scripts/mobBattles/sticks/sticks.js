import {world} from "@minecraft/server";

function addHealth(entity, amount){
	try{
	let component = entity.getComponent("minecraft:health");
	component.setCurrent(component.current+amount);
	}catch(error){};
}

class TriggerFromEventAndItem {
	constructor(itemTypeId="unknown"){
		this.typeId = itemTypeId;
		this._action = (e)=>{};
		this._callback = undefined;
		this.eventName = undefined;
	}
	subscribe(eventName){
		this.eventName = eventName;
		this._callback = world.afterEvents[this.eventName].subscribe((e)=>{
			this._action(e,this);
        });
	}
	unsubscribe (){
		world.afterEvents[this.eventName].unsubscribe(this._callback);
	}
}
const GroupOfEnemies = new TriggerFromEventAndItem("add:raid_stick");
GroupOfEnemies.getAllMembers = (entity,lore=[],type="air",limit=10)=>{
	const container=entity.getComponent("minecraft:inventory").container;
	const general = {lore:[],members:[]};
	for(let slot=0;slot<container.size;slot++){
		let itemSlot = container.getSlot(slot);
		if (itemSlot?.typeId==type){
		  let thisLore = (itemSlot.getLore()??[]);
		  thisLore = thisLore.filter((el)=>el.startsWith("§fMember: "));
		  (thisLore.length>general.lore.length) ? general.lore = thisLore : undefined;
		}
	};
	general.members = general.lore.map((el)=>el.replace("§fMember: ",""));
	return general;
};
GroupOfEnemies.appendLore = (entity,general,lore=[],type="air",limit=10)=>{
		const container=entity.getComponent("minecraft:inventory").container;
		for(let slot=0;slot<container.size;slot++){
			let itemSlot = container.getSlot(slot);
			if((itemSlot?.typeId==type)){
				let newLore = [];
				let externalLore = (itemSlot.getLore()??[]).filter((el)=>!el.startsWith("§fMember: "));
				let members = (itemSlot.getLore()??[]).filter((el)=>el.startsWith("§fMember: "));
				newLore.push(...externalLore);
				(members.length==general.length) ? [newLore.push(...members),newLore.push(...lore)] : [newLore.push(...general),newLore.push(...lore)];
				itemSlot.setLore(newLore);
			}
		}
	};
GroupOfEnemies._action = (e,from)=>{
	const { damagingEntity, hitEntity } = e;
	const entity = damagingEntity;
	const { typeId, appendLore, getAllMembers } = from;
	if(entity.typeId!="minecraft:player"|| !hitEntity) return;
	let item = entity.getComponent("minecraft:inventory").container.getItem(entity.selectedSlot);
	if(item?.typeId!=typeId) return;
	let lore = [ "§fMember: " + hitEntity.id ];
	let members = getAllMembers(entity,lore,typeId,10);
	if(members.members.some((el)=>el==hitEntity.id) ) return entity.sendMessage({ rawtext: [{text:"§c"}, {translate: "raidStick.error.sameEntity" } ] });
	if(members.members.length>=10) return entity.sendMessage({ rawtext: [ {text:"§c"}, {translate: "raidStick.error.length" } ] });
	hitEntity.addTag(hitEntity.id);
	appendLore(entity,members.lore,lore,typeId,10);
	entity.sendMessage({rawtext: [ {text: "§e"}, {translate: "raidStick.succes", with: [hitEntity.id] } ] });
};
GroupOfEnemies.subscribe("entityHitEntity");

const RaidInitializer = new TriggerFromEventAndItem("add:raid_initializer");
RaidInitializer.getAllMembers = GroupOfEnemies.getAllMembers;
RaidInitializer.clearMembers = (entity,typeId)=>{
	let container=entity.getComponent("minecraft:inventory").container;
	for(let slot=0;slot<container.size;slot++){
		let item = container.getSlot(slot);
		if(item?.typeId==typeId){
			let cache = (item.getLore()??[]).filter((el)=>el.startsWith("§fMember: "));
			let external= (item.getLore()??[]).filter((el)=>!el.startsWith("§fMember: "));
			item.setLore(external);
		}
	}
};
RaidInitializer._action = (e,from) => {
	const { damagingEntity, hitEntity } = e;
	const entity = damagingEntity;
	const { typeId, getAllMembers, clearMembers } = from;
	if(entity.typeId!="minecraft:player"|| !hitEntity) return;
	let item = entity.getComponent("minecraft:inventory").container.getItem(entity.selectedSlot);
	if(item?.typeId!=typeId) return;
	try{
	const members = getAllMembers(entity,[],GroupOfEnemies.typeId,10).members;
	if(members.some((el)=>el==hitEntity.id)){
      return entity.sendMessage({rawtext: [ {text: "§c"}, {translate: "raidInitializer.error.sameEntity" } ] });
    };
	for(let tag of members){
		const [member] = entity.dimension.getEntities({closest: 1, tags: [tag] });
		member?.applyDamage(1,{cause:"entityAttack",damagingEntity:hitEntity});
	};
	clearMembers(entity,GroupOfEnemies.typeId);
	entity.sendMessage( {rawtext: [ {text:"§e"},{translate: "raidInitializer.succes" } ] } );
	}catch(error){};
};
RaidInitializer.subscribe("entityHitEntity");

const TargetSetterStick = new TriggerFromEventAndItem("add:target_setter");
TargetSetterStick.mapa = new Map();
TargetSetterStick._action = (e,from) => {
	const { damagingEntity, hitEntity } = e;
	const entity = damagingEntity;
	const { typeId, mapa } = from;
	if(entity.typeId!="minecraft:player"|| !hitEntity) return;
	let item = entity.getComponent("minecraft:inventory").container.getItem(entity.selectedSlot);
	if(item?.typeId!=typeId) return;
	(!mapa.has(entity)) ? mapa.set(entity,[]) : undefined;
	let object = mapa.get(entity);
	const [target] = object;
	if(!target){
		object[0] = hitEntity;
		return entity.sendMessage({rawtext: [ {text: "§e" }, {translate: `entity.${hitEntity.typeId.replace("minecraft:","")}.name` }, {translate: "targetSetter.succes.first" } ] });
	};
	if(target==hitEntity) return entity.sendMessage({rawtext: [{text: "§c" }, {translate: "targetSetter.error.sameEntity" } ] });
	try{
    addHealth(target,1);
    addHealth(target,1);
	target.applyDamage(1, { cause: "entityAttack", damagingEntity: (hitEntity??null) } );
	hitEntity.applyDamage(1, { cause: "entityAttack", damagingEntity: (target??null) } );
	}catch(error){ entity.sendMessage({rawtext: [{text: "§c" }, {translate: "targetSetter.error.notFound" } ] }); };
	mapa.set(entity,[]);
};
TargetSetterStick.subscribe("entityHitEntity");

const KillerStick = new TriggerFromEventAndItem("add:killer_stick");
KillerStick._action = (e,from) => {
	const { damagingEntity, hitEntity } = e;
	const { typeId } = from;
	const entity = damagingEntity;
	if(entity.typeId!="minecraft:player"|| !hitEntity) return;
	let item = entity.getComponent("minecraft:inventory").container.getItem(entity.selectedSlot);
	if(item?.typeId!=typeId) return;
	hitEntity.kill();
};
KillerStick.subscribe("entityHitEntity");

const RiderSetter = new TriggerFromEventAndItem("add:rider_setter_stick");
RiderSetter.mapa = new Map();
RiderSetter._action = async (e,from) => {
	const { damagingEntity, hitEntity } = e;
	const { typeId, mapa } = from;
	const entity = damagingEntity;
	if(entity.typeId!="minecraft:player"|| !hitEntity) return;
	let item = entity.getComponent("minecraft:inventory").container.getItem(entity.selectedSlot);
	if(item?.typeId!=typeId) return;
	(!mapa.has(entity)) ? mapa.set(entity,[]) : undefined;
	let [ride] = mapa.get(entity);
	if(!ride){
		if(!hitEntity.hasComponent("minecraft:rideable")) return entity.sendMessage({ rawtext: [ {text: "§c" }, {translate: `entity.${hitEntity.typeId.replace("minecraft:","")}.name`}, {translate: "riderSetter.error.componentNotFound" } ] });
		mapa.get(entity)[0] = hitEntity;
		return entity.sendMessage({ rawtext: [ {text: "§e" }, {translate: `entity.${hitEntity.typeId.replace("minecraft:","")}.name`}, {translate: "riderSetter.succes.ride" } ] });
	};
	if(ride==hitEntity) return entity.sendMessage({rawtext: [{text: "§c" }, {translate: "riderSetter.error.sameEntity" } ] });
	try{
		let tag = "rider_"+hitEntity.id;
		ride.addTag(tag);
		addHealth(ride,1); addHealth(hitEntity,1);
		await hitEntity.runCommandAsync(`ride @s start_riding @e[tag=${tag}] teleport_rider`);
		ride.removeTag(tag);
	}catch(error){ entity.sendMessage({rawtext:[{text: "§c"},{translate: "riderSetter.error.operation" }]}); };
	mapa.set(entity,[]);
};
RiderSetter.subscribe("entityHitEntity");

const FireSetter = new TriggerFromEventAndItem("add:fire_setter");
FireSetter._action = (e,from)=>{
	const { damagingEntity, hitEntity } = e;
	const { typeId, mapa } = from;
	const entity = damagingEntity;
	if(entity.typeId!="minecraft:player"|| !hitEntity) return;
	let item = entity.getComponent("minecraft:inventory").container.getItem(entity.selectedSlot);
	if(item?.typeId!=typeId) return;
	hitEntity.setOnFire(100, true);
};
FireSetter.subscribe("entityHitEntity");

const TamerSetter = new TriggerFromEventAndItem("add:tamer_setter_stick");
TamerSetter._action = (e,from) => {
	const { damagingEntity, hitEntity } = e;
	const entity = damagingEntity;
	const { typeId } = from;
	if(entity.typeId!="minecraft:player"|| !hitEntity) return;
	let item = entity.getComponent("minecraft:inventory").container.getItem(entity.selectedSlot);
	if(item?.typeId!=typeId) return;
	let component = (hitEntity.getComponent("minecraft:tameable")||hitEntity.getComponent("minecraft:tamemount"));
	if(!component) return entity.sendMessage({rawtext: [{text: "§c" }, {translate: "tamerSetter.error.componentNotFound" } ] });
	addHealth(hitEntity,1);
	if(component.typeId=="minecraft:tameable"){
		return entity.sendMessage({true: {rawtext: [{text: "§e" }, {translate: `entity.${hitEntity.typeId.replace("minecraft:","")}.name`}, {translate: "tamerSetter.succes.tameable" }] }, false: {rawtext: [{text: "§c" }, {translate: "tamerSetter.error.operation" }]}}[component.tame()]);
	};
	 try{component.setTamed(true); entity.sendMessage({rawtext: [{text: "§e" },{translate: "tamerSetter.succes.tamemount" }] });}catch(error){entity.sendMessage({rawtext: [{text: "§e" }, {translate: "tamerSetter.error.operation" }] });};
};
TamerSetter.subscribe("entityHitEntity");

