

import {ItemStack} from "@minecraft/server";

export function getSlotInfo(entity,options){
	const { slot, empty, itemStack, typeId, nameTag, amount, containerType, equipmentType, slotType } = options;
	const data = {};
	try{
      if(containerType=="container"){
	    let container = entity.getComponent("minecraft:inventory").container;
	    let slotObj = container.getSlot(slot);
	    (amount) ? data.amount = slotObj.amount : undefined;
	    (empty) ? data.empty = (slotObj.amount<=0) : undefined;
	    try { (itemStack) ? data.itemStack = slotObj.getItem() : undefined;}catch(error){(itemStack) ? data.itemStack = new ItemStack("minecraft:air") : undefined;};
	    (typeId) ? data.typeId = slotObj.typeId : undefined;
	    (nameTag) ? data.nameTag=slotObj.nameTag : undefined;
	    (slotType) ? data.slotType = slotObj : undefined;
	  };
	  if(containerType=="equipment"){
		let equipment = entity.getComponent("minecraft:equipment_inventory").getEquipmentSlot(equipmentType);
		(amount) ? data.amount = equipment.amount : undefined;
		(empty) ? data.empty = (equipment.amount<=0) : undefined;
	   try { (itemStack) ? data.itemStack = equipment.getItem() : undefined;}catch(error){(itemStack) ? data.itemStack = new ItemStack("minecraft:air") : undefined;};
	    (typeId) ? data.typeId = equipment.typeId : undefined;
	    (nameTag) ? data.nameTag=equipment.nameTag : undefined;
	    (slotType) ? data.slotType = equipment : undefined;
	  }
    }catch(error){};
	return data;
}

      