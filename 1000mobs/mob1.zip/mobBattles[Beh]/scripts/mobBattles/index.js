import {world,system,ItemStack} from "@minecraft/server";
import {MOB_BATTLES_SCREENS} from "./user_interfaces/screens.js";
import "./sticks/sticks.js";


system.beforeEvents.watchdogTerminate.subscribe((e)=>{ e.cancel = true;});