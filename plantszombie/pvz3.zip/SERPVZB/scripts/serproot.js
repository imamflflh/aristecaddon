import{Player,Entity,Block,BlockType,EntityHealthComponent,ItemStack,Dimension,world,system}from"@minecraft/server";
import{ActionFormData}from"@minecraft/server-ui";
const ScoreboardAction={add:"add",remove:"remove",set:"set"};
function getScore(objectiveId,player){return world.scoreboard.getObjective(objectiveId).getScore(player.scoreboardIdentity);}
function setScore(entity,objectiveId,score, action){const objective=world.scoreboard.getObjective(objectiveId);if(!objective)throw new ReferenceError('Scoreboard objective does not exist in world.');const previousScore=!!entity.scoreboardIdentity?objective.getScore(entity.scoreboardIdentity):0;switch(action){case ScoreboardAction.add:score+=previousScore;break;case ScoreboardAction.remove:score-=previousScore;break;default:break;}if(!entity.scoreboardIdentity)entity.runCommand('scoreboard players set @s '+objective+' '+score);else {objective.setScore(entity.scoreboardIdentity, score);}};

system.runInterval(()=>{
Array.from(world.getPlayers()).forEach(player=>{
  if(!player.hasTag("started")){forms.start(player);player.runCommand('give @s serp:phone 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}');player.runCommand("scoreboard players add @s cooldown 0");player.runCommand("scoreboard players add @s sun 0");player.addTag("started");}
});
});
world.beforeEvents.itemUse.subscribe(pmenu=>{let item=pmenu.itemStack;let player=pmenu.source;
  if(item.typeId=="serp:phone"){system.run(()=>forms.main(player));system.run(()=>player.addTag("phone"));}
});
world.afterEvents.dataDrivenEntityTriggerEvent.subscribe((event)=>{let s=event.entity;let hp=s.getComponent('health');
  switch(event.id){
  case("serp:remove"):{if((s.typeId.startsWith("plant:"))&&!s.typeId.includes("cherry_bomb")&&!s.typeId.includes("doom_shroom")){s.runCommand("particle serp:plant_despawn ~~~");s.runCommand("playsound mob.horse.leather @p");}};break;
  case("serp:hypnotized"):{if(s.typeId.startsWith("zombie:")){s.runCommand("execute as @s anchored eyes run particle serp:hypno_spore ~~~");s.addTag("hypnotized");}};break;
  case("serp:death"):{if(s.typeId.startsWith("zombie:")){s.runCommand("playanimation @s animation.pvzzombiebasic.death");}};break;
  }
});
world.afterEvents.projectileHitEntity.subscribe((hit)=>{let s=hit.source;let p=hit.projectile;let e=hit.getEntityHit().entity;
if((p.typeId==="serp:pea"||p.typeId==="serp:spore"||p.typeId==="serp:butter")&&!e.typeId.startsWith("plant:")&&!e.hasTag("hypnotized")&&!p.hasTag("on_hit"))
{p.addTag("on_hit");
  if(e.typeId.startsWith("zombie:")&&p.hasTag("frozen")){e.triggerEvent("serp:frozen");e.runCommand("effect @s slowness 1 1 true");}
  if(e.typeId.startsWith("zombie:")&&p.hasTag("fire")){e.triggerEvent("serp:fire");e.runCommand("fill ~~1~ ~~1~ fire replace air");}
  if(e.typeId.startsWith("zombie:")&&p.typeId.includes("butter")){e.triggerEvent("serp:butter");e.runCommand("effect @s slowness 1 1 true");}
p.triggerEvent("serp:remove");}
});
world.afterEvents.entityHitEntity.subscribe((hit)=>{let victim=hit.hitEntity;let hitter=hit.damagingEntity;
  if(hitter.typeId==='minecraft:player'&&victim.typeId.startsWith("plant:")){let item=hitter.getComponent("inventory").container.getItem(hitter.selectedSlot);
  if(item.typeId.includes("shovel")){victim.triggerEvent("serp:remove");}
 }
});
class gui{
  start(player){const form=new ActionFormData();form.title("serp.crazy_dave.title");form.body("serp.pvz_start");form.button("gui.confirm");form.show(player).then(result=>{if(result.canceled||(!result.canceled)){}});}
  main(player){const form=new ActionFormData();form.title(` ${getScore('sun',player)}`);form.body("serp.pvz_store")
form.button("pvz.stuff","textures/items/iron_shovel")
form.button("day.plants","textures/ui/day")
form.button("night.plants","textures/ui/night")
    form.show(player).then(result=>{let response=result.selection;
  if(result.canceled){return player.removeTag("phone");}
      switch(response){
  case 0:{const form=new ActionFormData();form.title(` ${getScore('sun',player)}`);form.body("pvz.stuff")
form.button(" 2","textures/items/pvz/sun")
form.button(" 15","textures/items/pvz/lawn_mower")
    form.show(player).then(result=>{let response=result.selection;
  if(result.canceled){this.main(player);}else{
  switch(response){
    case 0:player.runCommand("scoreboard players add @s[hasitem={item=minecraft:rotten_flesh,quantity=5..}] sun 1");player.runCommand("clear @s[hasitem={item=minecraft:rotten_flesh,quantity=5..}] minecraft:rotten_flesh 0 5");break;
    case 1:player.runCommand("give @s[hasitem={item=minecraft:rotten_flesh,quantity=15..}] serp:lawn_mower");player.runCommand("clear @s[hasitem={item=minecraft:rotten_flesh,quantity=15..}] minecraft:rotten_flesh 0 15");break;
  }}
    });
  };break;
  case 1:{const articles=[{id:"plant:peashooter",icon:"textures/items/pvz/peashooter_seed",cost:4},{id:"plant:sunflower",icon:"textures/items/pvz/sunflower_seed",cost:2},{id:"plant:wallnut",icon:"textures/items/pvz/wallnut_seed",cost:2},{id:"plant:cherry_bomb",icon:"textures/items/pvz/cherry_bomb_seed",cost:6},{id:"plant:snow_pea",icon:"textures/items/pvz/snow_pea_seed",cost:7},{id:"plant:potatomine",icon:"textures/items/pvz/potatomine_seed",cost:1},{id:"plant:repeater",icon:"textures/items/pvz/repeater_seed",cost:8},{id:"plant:chomper",icon:"textures/items/pvz/chomper_seed",cost:6},{id:"plant:jalapeno",icon:"textures/items/pvz/jalapeno_seed",cost:5},{id:"plant:squash",icon:"textures/items/pvz/squash_seed",cost:4},{id:"plant:torchwood",icon:"textures/items/pvz/torchwood_seed",cost:7}];const form=new ActionFormData();form.title(` ${getScore('sun',player)}`);form.body("pvz.stuff")
  for(const article of articles){form.button(` ${article.cost}`,`${article.icon}`);}
    form.show(player).then(result=>{let response=result.selection;
  if(result.canceled){this.main(player);}else{for(const article of articles){
  if(articles.indexOf(article)==response){if(getScore("sun",player)>=article.cost){setScore(player,"sun",getScore("sun",player)-article.cost);player.runCommand(`tellraw @s {"rawtext":[{"translate":"store.buy"},{"translate":"entity.${article.id}.name"}]}`);player.runCommand(`give @s ${article.id}`);}else{player.runCommand(`tellraw @s {"rawtext":[{"translate":"store.dont_have_money"},{"translate":"entity.${article.id}.name"}]}`);}}
      }}
    });
  };break;
  case 2:{const articles=[{id:"plant:sun_shroom",icon:"textures/items/pvz/sun_shroom_seed",cost:1},{id:"plant:puff_shroom",icon:"textures/items/pvz/puff_shroom_seed",cost:1},{id:"plant:fume_shroom",icon:"textures/items/pvz/fume_shroom_seed",cost:3},{id:"plant:scaredy_shroom",icon:"textures/items/pvz/scaredy_shroom_seed",cost:1},{id:"plant:hypno_shroom",icon:"textures/items/pvz/hypno_shroom_seed",cost:3},];const form=new ActionFormData();form.title(` ${getScore('sun',player)}`);form.body("pvz.stuff")
  for(const article of articles){form.button(` ${article.cost}`,`${article.icon}`);}
    form.show(player).then(result=>{let response=result.selection;
  if(result.canceled){this.main(player);}else{for(const article of articles){
  if(articles.indexOf(article)==response){if(getScore("sun",player)>=article.cost){setScore(player,"sun",getScore("sun",player)-article.cost);player.runCommand(`tellraw @s {"rawtext":[{"translate":"store.buy"},{"translate":"entity.${article.id}.name"}]}`);player.runCommand(`give @s ${article.id}`);}else{player.runCommand(`tellraw @s {"rawtext":[{"translate":"store.dont_have_money"},{"translate":"entity.${article.id}.name"}]}`);}}
      }}
    });
  };break;
      }
    });
  }
}
const forms=new gui();